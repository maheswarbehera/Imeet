import React from 'react';
import Testimonial from './Testimonial';
import Herosection from './Herosection';

function Home() {
  return (
    <>
      
      <Testimonial/>
      <Herosection/>
    </>
  );
}

export default Home;
